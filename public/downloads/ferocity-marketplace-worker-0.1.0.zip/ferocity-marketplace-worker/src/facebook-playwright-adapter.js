import crypto from "node:crypto";
import fs from "node:fs";

const FACEBOOK_HOSTS = new Set(["facebook.com", "www.facebook.com", "m.facebook.com", "messenger.com", "www.messenger.com"]);

function stableId(value) {
  return crypto.createHash("sha256").update(value).digest("hex").slice(0, 32);
}

function facebookUrl(value) {
  try {
    const url = new URL(value);
    return FACEBOOK_HOSTS.has(url.hostname.toLowerCase()) ? url.toString() : null;
  } catch {
    return null;
  }
}

export class FacebookPlaywrightAdapter {
  constructor(config) {
    this.config = config;
    this.context = null;
    this.page = null;
    this.seen = new Map();
  }

  isRunning() {
    return Boolean(this.context && this.page && !this.page.isClosed());
  }

  async start() {
    if (this.isRunning()) return;
    if (this.context) await this.stop();
    fs.mkdirSync(this.config.profileDir, { recursive: true });
    const { chromium } = await import("playwright");
    const options = {
      headless: this.config.headless,
      viewport: { width: 1365, height: 900 },
      args: ["--disable-background-timer-throttling", "--disable-renderer-backgrounding"]
    };
    if (this.config.channel) options.channel = this.config.channel;
    this.context = await chromium.launchPersistentContext(this.config.profileDir, options);
    this.page = this.context.pages()[0] || await this.context.newPage();
    await this.page.goto(this.config.inboxUrl, { waitUntil: "domcontentloaded", timeout: 45_000 });
  }

  async stop() {
    const context = this.context;
    this.context = null;
    this.page = null;
    if (context) await context.close().catch(() => {});
  }

  async inspectHealth() {
    if (!this.isRunning()) {
      return { state: "ready", browserState: "closed", url: this.config.inboxUrl, reason: "Worker is healthy and the persistent Facebook session is idle." };
    }
    const url = this.page.url() || this.config.inboxUrl;
    const title = await this.page.title().catch(() => "");
    const text = await this.page.locator("body").innerText({ timeout: 5000 }).catch(() => "");
    const combined = `${title}\n${text}`;
    if (/checkpoint|confirm your identity|security check|enter (the )?code|captcha/i.test(combined)) {
      return { state: "verification_required", browserState: "attention_required", url, reason: "Facebook requires the account owner to complete a security check." };
    }
    if (/temporarily blocked|account restricted|you can(?:'|’)t use this feature|can(?:'|’)t send messages/i.test(combined)) {
      return { state: "restricted", browserState: "attention_required", url, reason: "Facebook reported a restriction or messaging block." };
    }
    if (/log into facebook|email address or phone number/i.test(combined) || /\/login(?:\/|\?|$)/i.test(url)) {
      return { state: "verification_required", browserState: "attention_required", url, reason: "The customer must sign into Facebook in the worker browser." };
    }
    if (!facebookUrl(url)) {
      return { state: "connector_incompatible", browserState: "failed", url: this.config.inboxUrl, reason: "The worker browser is not on a recognized Facebook or Messenger page." };
    }
    return { state: "ready", browserState: "ready", url, reason: "Facebook session is available." };
  }

  pruneSeen(now = Date.now()) {
    for (const [key, seenAt] of this.seen) {
      if (now - seenAt > 24 * 60 * 60 * 1000) this.seen.delete(key);
    }
    while (this.seen.size > 5000) this.seen.delete(this.seen.keys().next().value);
  }

  async collectObservations() {
    if (!this.isRunning()) throw new Error("Browser is not running.");
    const health = await this.inspectHealth();
    if (health.state !== "ready") return [];
    if (!facebookUrl(this.page.url())) await this.page.goto(this.config.inboxUrl, { waitUntil: "domcontentloaded", timeout: 45_000 });

    const discovered = await this.page.evaluate(() => {
      const links = [...document.querySelectorAll("a[href*='/messages/'],a[href*='messenger.com/t/']")];
      return links.map((link) => link.href).filter((href) => /\/messages\/(?:e2ee\/)?(?:requests\/)?t\/|messenger\.com\/t\//i.test(href));
    }).catch(() => []);
    const urls = [...new Set([this.page.url(), ...discovered].map(facebookUrl).filter(Boolean))]
      .slice(0, this.config.maxThreadsPerSweep);
    const observations = [];

    for (const url of urls) {
      if (this.page.url() !== url) {
        await this.page.goto(url, { waitUntil: "domcontentloaded", timeout: 45_000 }).catch(() => null);
        await this.page.waitForTimeout(900);
      }
      if (!/\/messages\/(?:e2ee\/)?(?:requests\/)?t\/|messenger\.com\/t\//i.test(this.page.url())) continue;
      const extracted = await this.page.evaluate(() => {
        const textOf = (node) => (node?.innerText || node?.textContent || "").replace(/\s+/g, " ").trim();
        const system = (text) => /^(search|chats?|messages?|message requests?|notifications?|new message|active now|compose|messenger|delivered|seen)$/i.test(text)
          || /^messages and calls are secured with end-to-end encryption/i.test(text)
          || /^\d{1,2}:\d{2}\s*(am|pm)?$/i.test(text);
        const path = location.pathname;
        const thread = path.match(/\/messages\/(?:e2ee\/)?(?:requests\/)?t\/([^/]+)/i)?.[1]
          || path.match(/\/t\/([^/]+)/i)?.[1] || path;
        const selectors = ["[data-scope='messages_table'] [role='row']", "[aria-label*='Message'] [dir='auto']", "[role='log'] [dir='auto']"];
        const nodes = selectors.flatMap((selector) => [...document.querySelectorAll(selector)]).slice(-50);
        return nodes.map((node) => {
          const body = textOf(node);
          const aria = [node.getAttribute("aria-label"), node.closest("[aria-label]")?.getAttribute("aria-label")].filter(Boolean).join(" ");
          const rect = node.getBoundingClientRect();
          const outgoing = /you sent|sent by you|^you[:\s]/i.test(aria) || rect.left >= innerWidth * 0.62;
          const match = aria.match(/(?:^|,\s*)([^:,]{2,80}):\s+.+$/);
          const header = textOf(document.querySelector("[role='main'] h1")) || textOf(document.querySelector("h1"));
          const name = (match?.[1] || header || thread).replace(/\s+Unread message:.*$/i, "").replace(/\s+·\s+.*$/i, "").trim();
          return { body, aria, outgoing, name, thread };
        }).filter((item) => item.body.length >= 2 && item.body.length <= 4000 && !item.outgoing && !system(item.body) && item.aria);
      }).catch(() => []);

      for (const item of extracted) {
        const key = `${item.thread}:${stableId(item.body)}`;
        if (this.seen.has(key)) continue;
        this.seen.set(key, Date.now());
        observations.push({
          providerEventId: `fb-worker:${key}`,
          externalConversationRef: item.thread,
          externalActorId: item.name || item.thread,
          displayName: item.name || undefined,
          body: item.body,
          sourceUrl: this.page.url(),
          surface: "messenger",
          connectorVersion: "marketplace-worker-0.1.0",
          observedAt: new Date().toISOString()
        });
      }
    }
    this.pruneSeen();
    return observations;
  }

  async executeAction(action) {
    if (!this.isRunning()) return { outcome: "failed", failureCode: "browser_not_running", failureMessage: "The worker browser was not running." };
    const destination = facebookUrl(action.sourceUrl);
    if (!destination) return { outcome: "blocked", failureCode: "missing_safe_destination", failureMessage: "The approved action did not include a recognized Facebook conversation URL." };
    const body = String(action.body || "").trim();
    if (!body) return { outcome: "blocked", failureCode: "empty_message", failureMessage: "The approved action had no message body." };

    await this.page.goto(destination, { waitUntil: "domcontentloaded", timeout: 45_000 });
    await this.page.waitForTimeout(1000);
    const health = await this.inspectHealth();
    if (health.state !== "ready") {
      return { outcome: "blocked", failureCode: health.state, failureMessage: health.reason, observedUrl: this.page.url() };
    }

    const selectors = [
      "[contenteditable='true'][role='textbox']",
      "[aria-label*='Message'][contenteditable='true']",
      "[data-lexical-editor='true']",
      "textarea[aria-label*='Message']"
    ];
    let composer = null;
    for (const selector of selectors) {
      const candidates = this.page.locator(selector);
      for (let index = (await candidates.count()) - 1; index >= 0; index -= 1) {
        const candidate = candidates.nth(index);
        if (await candidate.isVisible().catch(() => false)) {
          composer = candidate;
          break;
        }
      }
      if (composer) break;
    }
    if (!composer) return { outcome: "failed", failureCode: "composer_not_found", failureMessage: "Facebook's visible message composer could not be identified.", observedUrl: this.page.url() };

    await composer.fill(body).catch(async () => {
      await composer.click();
      await this.page.keyboard.press("Control+A");
      await this.page.keyboard.type(body, { delay: 8 });
    });
    await this.page.waitForTimeout(500 + Math.floor(Math.random() * 500));
    await composer.press("Enter");
    await this.page.waitForTimeout(1200);
    const remaining = String(await composer.textContent().catch(() => "") || await composer.inputValue().catch(() => "")).trim();
    if (remaining) return { outcome: "failed", failureCode: "send_unconfirmed", failureMessage: "The composer did not clear after the send attempt; Ferocity will not retry automatically.", observedUrl: this.page.url() };
    return {
      outcome: "succeeded",
      providerReference: `fb-worker:${action.id}:${Date.now()}`,
      observedUrl: this.page.url()
    };
  }
}
