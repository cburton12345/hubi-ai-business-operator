@echo off
cd /d "%~dp0"
npm run logs
